{pkgs}: {
  deps = [
    pkgs.jq
  ];
}
