import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import {
  Shield, CheckCircle2, XCircle, Clock, Search, Building2, FileText,
  BarChart3, TrendingUp, AlertTriangle, Download, RefreshCw, Gavel,
  Award, CheckCircle, Pencil, History, ArrowRight,
} from "lucide-react";
import { format } from "date-fns";

const ASSET_TYPE_LABELS: Record<string, string> = {
  real_estate: "Real Estate", vehicle: "Vehicle", equipment: "Equipment",
  inventory: "Inventory", securities: "Securities", land: "Land",
  livestock: "Livestock", crop: "Crops", other: "Other",
};

interface ActiveLienItem {
  id: string;
  registrationNumber?: string;
  panAfricanAssetId?: string;
  assetLocalIdentifier?: string;
  collateralType: string;
  borrowerName?: string;
  borrowerId?: string;
  lenderOrganizationId?: string;
  lenderInstitution?: string;
  lenderInstitutionName?: string;
  estimatedValue?: string;
  currency?: string;
  approvalDate?: string;
  certificateNumber?: string;
  lienPriority?: number;
  status?: string;
  enforcementStatus?: string;
  description?: string;
  countryCode?: string;
}

interface PendingItem {
  id: string;
  registrationNumber?: string;
  panAfricanAssetId?: string;
  assetLocalIdentifier?: string;
  collateralType: string;
  borrowerName?: string;
  borrowerId?: string;
  lenderOrganizationId?: string;
  lenderInstitution?: string;
  lenderInstitutionName?: string;
  estimatedValue?: string;
  currency?: string;
  countryCode?: string;
  description?: string;
  legalRegime?: string;
  requiredFieldsJson?: string;
  createdAt?: string;
  resubmittedFromId?: string;
  resubmittedFromRegistrationNumber?: string;
  rejectionReason?: string;
  approvalStatus?: string;
}

interface HistoryItem {
  id: string;
  registrationNumber?: string;
  collateralType?: string;
  borrowerName?: string;
  estimatedValue?: string;
  currency?: string;
  description?: string;
  approvalStatus?: string;
  rejectionReason?: string;
  createdAt?: string;
  resubmittedFromId?: string;
}

const REGIME_COLORS: Record<string, string> = {
  "OHADA": "bg-purple-100 text-purple-700",
  "Civil Law": "bg-blue-100 text-blue-700",
  "Common Law": "bg-green-100 text-green-700",
  "Customary Law": "bg-orange-100 text-orange-700",
};

function formatVal(v: number) {
  return v.toLocaleString("en", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function formatCurrency(amount: string | number | null, currency = "GHS") {
  if (!amount) return "—";
  return `${currency} ${Number(amount).toLocaleString("en", { minimumFractionDigits: 2 })}`;
}

function PriorityBadge({ rank }: { rank: number | null }) {
  if (!rank) return <span className="text-muted-foreground text-xs">—</span>;
  const color = rank === 1 ? "bg-amber-100 text-amber-800" : rank === 2 ? "bg-slate-100 text-slate-700" : "bg-gray-100 text-gray-600";
  return <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${color}`}>#{rank}</span>;
}

function ApproveDialog({ item, countryCode }: { item: PendingItem; countryCode: string }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const mutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/collateral/${item.id}/approve`, {}),
    onSuccess: () => {
      toast({ title: "Lien approved", description: `Certificate issued for ${item.registrationNumber}.` });
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/active-liens", countryCode] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1 text-green-600 border-green-200" data-testid={`btn-approve-${item.id}`}>
          <CheckCircle2 className="w-3.5 h-3.5" /> Approve
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Approve Lien Registration</DialogTitle></DialogHeader>
        <p className="text-sm text-muted-foreground">You are about to approve this registration and issue a Certificate of Collateral Registration. Priority rank will be automatically assigned.</p>
        <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1">
          <div><span className="font-medium">Reg #:</span> {item.registrationNumber}</div>
          <div><span className="font-medium">Asset:</span> {ASSET_TYPE_LABELS[item.collateralType] || item.collateralType}</div>
          <div><span className="font-medium">Description:</span> {item.description}</div>
          <div><span className="font-medium">Value:</span> {formatCurrency(item.estimatedValue ?? null, item.currency ?? undefined)}</div>
          {item.panAfricanAssetId && <div><span className="font-medium">Pan-African ID:</span> {item.panAfricanAssetId}</div>}
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={() => mutation.mutate()} disabled={mutation.isPending} className="gap-2 bg-green-600 hover:bg-green-700">
            <CheckCircle2 className="w-4 h-4" /> {mutation.isPending ? "Approving..." : "Approve & Issue Certificate"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RejectDialog({ item }: { item: PendingItem }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const mutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/collateral/${item.id}/reject`, { reason }),
    onSuccess: () => {
      toast({ title: "Registration rejected" });
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/pending"] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1 text-red-600 border-red-200" data-testid={`btn-reject-${item.id}`}>
          <XCircle className="w-3.5 h-3.5" /> Reject
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Reject Registration</DialogTitle></DialogHeader>
        <div className="bg-muted/50 rounded-lg p-3 text-sm">
          <div><span className="font-medium">Reg #:</span> {item.registrationNumber}</div>
          <div><span className="font-medium">Asset:</span> {item.description}</div>
        </div>
        <div>
          <Label>Rejection Reason <span className="text-red-500">*</span></Label>
          <Textarea
            data-testid="input-rejection-reason"
            placeholder="State the reason for rejection..."
            value={reason}
            onChange={e => setReason(e.target.value)}
            className="mt-1"
          />
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="destructive" onClick={() => mutation.mutate()} disabled={!reason.trim() || mutation.isPending}>
            {mutation.isPending ? "Rejecting..." : "Confirm Rejection"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EnforceDischargeButtons({ item, countryCode }: { item: ActiveLienItem; countryCode: string }) {
  const { toast } = useToast();
  const enforceMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/collateral/${item.id}/enforce`, {}),
    onSuccess: () => {
      toast({ title: "Lien flagged as in enforcement" });
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/active-liens", countryCode] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });
  const dischargeMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/collateral/${item.id}/discharge`, {}),
    onSuccess: () => {
      toast({ title: "Lien discharged", description: "Asset is now free." });
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/active-liens", countryCode] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });
  return (
    <div className="flex gap-1">
      {item.status === "active" && !item.enforcementStatus && (
        <Button variant="ghost" size="sm" onClick={() => enforceMutation.mutate()} disabled={enforceMutation.isPending}
          title="Flag as In Enforcement" data-testid={`btn-enforce-${item.id}`}>
          <AlertTriangle className="w-4 h-4 text-amber-500" />
        </Button>
      )}
      {item.status === "active" && (
        <Button variant="ghost" size="sm" onClick={() => dischargeMutation.mutate()} disabled={dischargeMutation.isPending}
          title="Discharge lien" data-testid={`btn-discharge-${item.id}`}>
          <CheckCircle2 className="w-4 h-4 text-green-600" />
        </Button>
      )}
    </div>
  );
}

interface AmendmentRequestItem {
  id: string;
  collateralItemId: string;
  requestedBy: string;
  lenderOrganizationId: string;
  proposedChanges: string;
  amendmentReason: string;
  status: string;
  reviewedBy: string | null;
  reviewNotes: string | null;
  reviewedAt: string | null;
  createdAt: string;
  registrationNumber?: string;
  collateralType?: string;
  lenderOrgName?: string;
  requesterName?: string;
}

function ApproveAmendmentDialog({ req }: { req: AmendmentRequestItem }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  let proposed: Record<string, unknown> = {};
  try { proposed = JSON.parse(req.proposedChanges); } catch {}

  const mutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/collateral/amendment-requests/${req.id}/approve`, {}),
    onSuccess: () => {
      toast({ title: "Amendment approved", description: "The collateral record has been updated." });
      setOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/amendment-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/collateral", req.collateralItemId, "amendment-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/active-liens"] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1 text-green-600 border-green-200" data-testid={`btn-approve-amendment-${req.id}`}>
          <CheckCircle2 className="w-3.5 h-3.5" /> Approve
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Approve Amendment Request</DialogTitle></DialogHeader>
        <p className="text-sm text-muted-foreground">Approving this request will immediately apply the proposed changes to the active registration.</p>
        <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1">
          <div><span className="font-medium">Reg #:</span> {req.registrationNumber}</div>
          <div><span className="font-medium">Institution:</span> {req.lenderOrgName}</div>
          <div><span className="font-medium">Reason:</span> {req.amendmentReason}</div>
        </div>
        {Object.keys(proposed).length > 0 && (
          <div className="bg-blue-50 dark:bg-blue-950/20 rounded-lg p-3 text-sm space-y-1">
            <p className="font-medium text-blue-800 dark:text-blue-200 text-xs mb-2">Proposed Changes</p>
            {Object.entries(proposed).filter(([, v]) => v !== null && v !== "").map(([k, v]) => (
              <div key={k} className="flex gap-2 text-xs">
                <span className="text-muted-foreground w-32 shrink-0">{k}</span>
                <span className="font-medium">{String(v)}</span>
              </div>
            ))}
          </div>
        )}
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={() => mutation.mutate()} disabled={mutation.isPending} className="gap-2 bg-green-600 hover:bg-green-700">
            <CheckCircle2 className="w-4 h-4" /> {mutation.isPending ? "Approving..." : "Approve & Apply Changes"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function RejectAmendmentDialog({ req }: { req: AmendmentRequestItem }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState("");

  const mutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/collateral/amendment-requests/${req.id}/reject`, { reviewNotes: notes }),
    onSuccess: () => {
      toast({ title: "Amendment rejected" });
      setOpen(false);
      setNotes("");
      queryClient.invalidateQueries({ queryKey: ["/api/collateral/amendment-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/collateral", req.collateralItemId, "amendment-requests"] });
    },
    onError: (e: Error) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1 text-red-600 border-red-200" data-testid={`btn-reject-amendment-${req.id}`}>
          <XCircle className="w-3.5 h-3.5" /> Reject
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Reject Amendment Request</DialogTitle></DialogHeader>
        <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1">
          <div><span className="font-medium">Reg #:</span> {req.registrationNumber}</div>
          <div><span className="font-medium">Institution:</span> {req.lenderOrgName}</div>
          <div><span className="font-medium">Reason requested:</span> {req.amendmentReason}</div>
        </div>
        <div>
          <Label>Rejection Notes <span className="text-red-500">*</span></Label>
          <Textarea
            data-testid="input-amendment-rejection-notes"
            placeholder="Explain why this amendment is being rejected…"
            value={notes}
            onChange={e => setNotes(e.target.value)}
            className="mt-1"
          />
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button variant="destructive" onClick={() => mutation.mutate()} disabled={!notes.trim() || mutation.isPending}>
            {mutation.isPending ? "Rejecting..." : "Confirm Rejection"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
};

function ResubmissionHistoryDialog({ item }: { item: PendingItem }) {
  const [open, setOpen] = useState(false);
  const { data: chain = [], isLoading, isError } = useQuery<HistoryItem[]>({
    queryKey: ["/api/collateral/history", item.id],
    queryFn: () => fetch(`/api/collateral/${item.id}/history`, { credentials: "include" }).then(r => { if (!r.ok) throw new Error(`${r.status}`); return r.json(); }),
    enabled: open,
    retry: false,
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          className="inline-flex items-center gap-1 text-xs text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-700 rounded px-1.5 py-0.5 hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors cursor-pointer font-sans mt-0.5"
          data-testid={`badge-resubmission-${item.id}`}
          onClick={e => e.stopPropagation()}
        >
          <History className="w-3 h-3 flex-shrink-0" />
          Resubmission of #{item.resubmittedFromRegistrationNumber ?? item.resubmittedFromId?.slice(0, 8)}
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-amber-600" />
            Resubmission History — {item.registrationNumber}
          </DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">Full chain of submissions for this financing statement, from original to the current pending resubmission.</p>
        {isLoading ? (
          <div className="text-center text-muted-foreground py-8">Loading history…</div>
        ) : isError ? (
          <div className="flex items-start gap-2 text-sm text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded px-3 py-3" data-testid="history-error">
            <XCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>Unable to load resubmission history. The history may be unavailable or you may not have access to view it.</span>
          </div>
        ) : chain.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">No history found.</div>
        ) : (
          <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1" data-testid="resubmission-history-chain">
            {chain.map((entry, idx) => {
              const isCurrent = entry.id === item.id;
              return (
                <div key={entry.id}>
                  {idx > 0 && (
                    <div className="flex items-center justify-center my-1">
                      <ArrowRight className="w-4 h-4 text-muted-foreground rotate-90" />
                    </div>
                  )}
                  <div
                    className={`rounded-lg border p-3 space-y-1.5 ${isCurrent ? "border-primary/40 bg-primary/5" : "bg-muted/40"}`}
                    data-testid={`history-entry-${entry.id}`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold">
                          {entry.registrationNumber || entry.id.slice(0, 8)}
                        </span>
                        {isCurrent && (
                          <Badge className="text-xs bg-primary/10 text-primary border-primary/20 border">
                            Current (Pending)
                          </Badge>
                        )}
                        {!isCurrent && idx === 0 && (
                          <Badge className="text-xs bg-blue-100 text-blue-700">Original</Badge>
                        )}
                        {!isCurrent && idx > 0 && idx < chain.length - 1 && (
                          <Badge className="text-xs bg-slate-100 text-slate-600">Resubmission {idx}</Badge>
                        )}
                      </div>
                      <Badge className={`text-xs ${STATUS_COLORS[entry.approvalStatus || ""] || "bg-gray-100 text-gray-600"}`}>
                        {entry.approvalStatus === "approved" && <CheckCircle2 className="w-3 h-3 inline mr-1" />}
                        {entry.approvalStatus === "rejected" && <XCircle className="w-3 h-3 inline mr-1" />}
                        {entry.approvalStatus === "pending" && <Clock className="w-3 h-3 inline mr-1" />}
                        {entry.approvalStatus || "unknown"}
                      </Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {ASSET_TYPE_LABELS[entry.collateralType || ""] || entry.collateralType || "—"}
                      {entry.borrowerName ? ` · ${entry.borrowerName}` : ""}
                      {entry.estimatedValue ? ` · ${formatCurrency(entry.estimatedValue, entry.currency)}` : ""}
                    </div>
                    {entry.description && (
                      <div className="text-xs text-foreground/70">{entry.description}</div>
                    )}
                    {entry.rejectionReason && (
                      <div className="flex items-start gap-1.5 text-xs text-red-700 dark:text-red-400 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded px-2 py-1.5 mt-1">
                        <XCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                        <span data-testid={`history-rejection-${entry.id}`}><span className="font-medium">Rejection reason:</span> {entry.rejectionReason}</span>
                      </div>
                    )}
                    {entry.createdAt && (
                      <div className="text-xs text-muted-foreground">
                        Submitted {format(new Date(entry.createdAt), "dd MMM yyyy")}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <Separator />
        <div className="flex justify-end">
          <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AmendmentQueue() {
  const [statusFilter, setStatusFilter] = useState("pending");
  const { data: requests = [], isLoading } = useQuery<AmendmentRequestItem[]>({
    queryKey: ["/api/collateral/amendment-requests"],
  });

  const filtered = requests.filter(r => statusFilter === "all" || r.status === statusFilter);
  const pendingCount = requests.filter(r => r.status === "pending").length;

  const AMENDMENT_STATUS_COLORS: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    approved: "bg-green-100 text-green-700",
    rejected: "bg-red-100 text-red-700",
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 items-center">
        <Button
          size="sm"
          variant={statusFilter === "pending" ? "default" : "outline"}
          onClick={() => setStatusFilter("pending")}
          data-testid="filter-amendments-pending"
        >
          Pending {pendingCount > 0 && <span className="ml-1 bg-amber-500 text-white text-xs rounded-full px-1.5 py-0.5">{pendingCount}</span>}
        </Button>
        <Button size="sm" variant={statusFilter === "approved" ? "default" : "outline"} onClick={() => setStatusFilter("approved")} data-testid="filter-amendments-approved">Approved</Button>
        <Button size="sm" variant={statusFilter === "rejected" ? "default" : "outline"} onClick={() => setStatusFilter("rejected")} data-testid="filter-amendments-rejected">Rejected</Button>
        <Button size="sm" variant={statusFilter === "all" ? "default" : "outline"} onClick={() => setStatusFilter("all")} data-testid="filter-amendments-all">All</Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-24 bg-muted/40 rounded-lg animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <CheckCircle className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p>No {statusFilter !== "all" ? statusFilter : ""} amendment requests.</p>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Registration</TableHead>
                <TableHead>Institution</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(req => {
                let proposed: Record<string, unknown> = {};
                try { proposed = JSON.parse(req.proposedChanges); } catch {}
                const fieldCount = Object.keys(proposed).filter(k => proposed[k] !== null && proposed[k] !== "").length;
                return (
                  <TableRow key={req.id} data-testid={`row-amendment-${req.id}`}>
                    <TableCell className="font-mono text-xs">{req.registrationNumber || req.collateralItemId.slice(0, 8)}</TableCell>
                    <TableCell className="text-sm">{req.lenderOrgName || "—"}</TableCell>
                    <TableCell className="text-sm max-w-xs">
                      <p className="truncate">{req.amendmentReason}</p>
                      <p className="text-xs text-muted-foreground">{fieldCount} field{fieldCount !== 1 ? "s" : ""} proposed</p>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{format(new Date(req.createdAt), "dd MMM yyyy")}</TableCell>
                    <TableCell>
                      <Badge className={`text-xs ${AMENDMENT_STATUS_COLORS[req.status] || "bg-gray-100 text-gray-600"}`}>{req.status}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      {req.status === "pending" && (
                        <div className="flex gap-1 justify-end">
                          <ApproveAmendmentDialog req={req} />
                          <RejectAmendmentDialog req={req} />
                        </div>
                      )}
                      {req.status !== "pending" && req.reviewNotes && (
                        <span className="text-xs text-muted-foreground italic truncate max-w-[120px] block">{req.reviewNotes}</span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

function PendingQueue({ orgId, countryCode }: { orgId: string; countryCode: string }) {
  const [search, setSearch] = useState("");
  const { data: items = [], isLoading } = useQuery<PendingItem[]>({
    queryKey: ["/api/collateral/pending"],
    queryFn: () => fetch("/api/collateral/pending", { credentials: "include" }).then(r => { if (!r.ok) throw new Error(`${r.status}`); return r.json(); }),
  });
  const filtered = items.filter(i => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      i.registrationNumber?.toLowerCase().includes(q) ||
      i.description?.toLowerCase().includes(q) ||
      i.assetLocalIdentifier?.toLowerCase().includes(q) ||
      i.lenderInstitutionName?.toLowerCase().includes(q) ||
      i.lenderInstitution?.toLowerCase().includes(q)
    );
  });
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input data-testid="input-search-pending" placeholder="Search pending registrations..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Badge className="bg-amber-100 text-amber-800">{items.length} pending</Badge>
      </div>
      {isLoading ? (
        <div className="text-center text-muted-foreground p-8">Loading pending registrations...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center p-12 space-y-2">
          <Clock className="w-10 h-10 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">{search ? "No matching registrations." : "No pending registrations. All clear!"}</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reg #</TableHead>
                <TableHead>Asset Type</TableHead>
                <TableHead>Submitted By</TableHead>
                <TableHead>Pan-African ID</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-right">Value</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Legal Regime</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((item) => (
                <TableRow key={item.id} data-testid={`row-pending-${item.id}`}>
                  <TableCell className="font-mono text-xs">
                    <div>{item.registrationNumber}</div>
                    {item.resubmittedFromId && (
                      <ResubmissionHistoryDialog item={item} />
                    )}
                  </TableCell>
                  <TableCell className="text-sm">{ASSET_TYPE_LABELS[item.collateralType] || item.collateralType}</TableCell>
                  <TableCell className="text-sm" data-testid={`text-lender-${item.id}`}>
                    {item.lenderInstitutionName || item.lenderInstitution || <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">{item.panAfricanAssetId || "—"}</TableCell>
                  <TableCell className="text-sm max-w-[180px] truncate">{item.description}</TableCell>
                  <TableCell className="text-right text-sm">{formatCurrency(item.estimatedValue ?? null, item.currency ?? undefined)}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{item.createdAt ? format(new Date(item.createdAt), "dd MMM yyyy") : "—"}</TableCell>
                  <TableCell>
                    {item.legalRegime ? (
                      <Badge className={`text-xs ${REGIME_COLORS[item.legalRegime] || "bg-gray-100 text-gray-600"}`}>{item.legalRegime}</Badge>
                    ) : "—"}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <ApproveDialog item={item} countryCode={countryCode} />
                      <RejectDialog item={item} />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

function ActiveLiensLedger({ countryCode }: { countryCode: string }) {
  const [search, setSearch] = useState("");
  const { data: items = [], isLoading } = useQuery<ActiveLienItem[]>({
    queryKey: ["/api/collateral/active-liens", countryCode],
    queryFn: () => fetch(`/api/collateral/active-liens?countryCode=${encodeURIComponent(countryCode)}`, { credentials: "include" }).then(r => { if (!r.ok) throw new Error(`${r.status}`); return r.json(); }),
  });
  const filtered = items.filter(i => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      i.registrationNumber?.toLowerCase().includes(q) ||
      i.description?.toLowerCase().includes(q) ||
      i.panAfricanAssetId?.toLowerCase().includes(q) ||
      i.assetLocalIdentifier?.toLowerCase().includes(q) ||
      i.borrowerName?.toLowerCase().includes(q) ||
      i.lenderInstitutionName?.toLowerCase().includes(q) ||
      i.lenderInstitution?.toLowerCase().includes(q)
    );
  });
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input data-testid="input-search-active-liens" placeholder="Search by asset ID, borrower, or institution..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Badge className="bg-green-100 text-green-800">{items.length} active liens</Badge>
      </div>
      {isLoading ? (
        <div className="text-center text-muted-foreground p-8">Loading active liens...</div>
      ) : filtered.length === 0 ? (
        <div className="text-center p-12 space-y-2">
          <FileText className="w-10 h-10 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">{search ? "No matching liens." : "No active liens registered yet."}</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Priority</TableHead>
                <TableHead>Cert #</TableHead>
                <TableHead>Pan-African ID</TableHead>
                <TableHead>Asset Type</TableHead>
                <TableHead>Borrower</TableHead>
                <TableHead className="text-right">Value</TableHead>
                <TableHead>Approved</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((item) => (
                <TableRow key={item.id} data-testid={`row-lien-${item.id}`}>
                  <TableCell><PriorityBadge rank={item.lienPriority ?? null} /></TableCell>
                  <TableCell className="font-mono text-xs">{item.certificateNumber || "—"}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">{item.panAfricanAssetId || item.assetLocalIdentifier || "—"}</TableCell>
                  <TableCell className="text-sm">{ASSET_TYPE_LABELS[item.collateralType] || item.collateralType}</TableCell>
                  <TableCell className="text-sm">{item.borrowerName || item.borrowerId}</TableCell>
                  <TableCell className="text-right text-sm">{formatCurrency(item.estimatedValue ?? null, item.currency ?? undefined)}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{item.approvalDate || "—"}</TableCell>
                  <TableCell>
                    <Badge className={`text-xs ${item.enforcementStatus === "in_enforcement" ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`}>
                      {item.enforcementStatus === "in_enforcement" ? "In Enforcement" : "Active"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <EnforceDischargeButtons item={item} countryCode={countryCode} />
                      <Button
                        variant="ghost"
                        size="sm"
                        data-testid={`btn-cert-download-${item.id}`}
                        title="Download Certificate"
                        onClick={() => {
                          const a = document.createElement("a");
                          a.href = `/api/collateral/${item.id}/certificate`;
                          a.download = `cert-${item.registrationNumber || item.id}.pdf`;
                          a.click();
                        }}
                        className="gap-1 text-xs"
                      >
                        <Download className="w-3 h-3" />
                        Cert
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}

interface ReportRow { orgId?: string; orgName?: string; type?: string; sector?: string; count: number; value?: number }
interface RegulatoryReport {
  totalActive: number;
  totalValue: number;
  byInstitution: ReportRow[];
  byAssetType: ReportRow[];
  bySector: ReportRow[];
}

function RegulatoryReports({ countryCode }: { countryCode: string }) {
  const { data: report, isLoading } = useQuery<RegulatoryReport>({
    queryKey: ["/api/collateral/regulatory-report", countryCode],
    queryFn: () => fetch(`/api/collateral/regulatory-report?countryCode=${encodeURIComponent(countryCode)}`, { credentials: "include" }).then(r => { if (!r.ok) throw new Error(`${r.status}`); return r.json(); }),
  });

  const exportCsv = () => {
    if (!report) return;
    const rows = [
      ["Institution", "Lien Count", "Total Value"],
      ...report.byInstitution.map((r) => [r.orgName, r.count, r.value]),
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `collateral-report-${countryCode}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) return <div className="text-center text-muted-foreground p-8">Loading report...</div>;
  if (!report) return <div className="text-center p-8 text-muted-foreground">No data available.</div>;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-3xl font-bold text-primary" data-testid="text-total-active-liens">{formatVal(report.totalActive)}</div>
            <div className="text-sm text-muted-foreground">Active Liens</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{formatVal(report.totalValue)}</div>
            <div className="text-sm text-muted-foreground">Total Collateral Value</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Building2 className="w-4 h-4" /> By Institution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {report.byInstitution.length === 0 ? (
                <p className="text-xs text-muted-foreground">No data</p>
              ) : report.byInstitution.map((r) => (
                <div key={r.orgId} className="flex justify-between text-sm">
                  <span className="truncate text-muted-foreground" title={r.orgName}>{r.orgName}</span>
                  <span className="font-medium ml-2">{r.count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <BarChart3 className="w-4 h-4" /> By Asset Type
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {report.byAssetType.length === 0 ? (
                <p className="text-xs text-muted-foreground">No data</p>
              ) : report.byAssetType.map((r) => (
                <div key={r.type} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{ASSET_TYPE_LABELS[r.type as string] || r.type}</span>
                  <span className="font-medium">{r.count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="w-4 h-4" /> By Sector
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {report.bySector.length === 0 ? (
                <p className="text-xs text-muted-foreground">No data</p>
              ) : report.bySector.map((r: any) => (
                <div key={r.sector} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{r.sector}</span>
                  <span className="font-medium">{r.count}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button variant="outline" onClick={exportCsv} className="gap-2" data-testid="btn-export-report-csv">
          <Download className="w-4 h-4" /> Export CSV
        </Button>
      </div>
    </div>
  );
}

export default function RegistryAuthorityPortal() {
  const { user } = useAuth();
  const org = user?.organization;

  // Dynamically resolve country code from registry_country_config using org's country name
  interface CountryConfig { countryCode: string; countryName: string; legalRegime: string; authorityName: string }
  const { data: countryConfigs = [] } = useQuery<CountryConfig[]>({
    queryKey: ["/api/registry-country-config"],
  });
  const countryCode: string = (() => {
    if (!org?.country) return "GH";
    const rawCountry = org.country.trim();
    // If it's already a 2-char ISO code, use it directly
    if (rawCountry.length === 2) return rawCountry.toUpperCase();
    // Look up by countryName in the fetched config (covers all 54 countries)
    const cfg = countryConfigs.find(
      (c) => c.countryName?.toLowerCase() === rawCountry.toLowerCase()
    );
    return cfg?.countryCode || rawCountry.toUpperCase().slice(0, 2) || "GH";
  })();

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold">{org?.name || "Registry Authority"}</h1>
              <p className="text-xs text-muted-foreground">Pan-African Collateral Registry — Government Portal</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-primary/10 text-primary">
              {org?.country || ""}
            </Badge>
            <Button variant="outline" size="sm" onClick={() => {
              queryClient.invalidateQueries({ queryKey: ["/api/collateral/pending"] });
              queryClient.invalidateQueries({ queryKey: ["/api/collateral/active-liens", countryCode] });
              queryClient.invalidateQueries({ queryKey: ["/api/collateral/regulatory-report", countryCode] });
            }} data-testid="btn-refresh-portal">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6">
        <Tabs defaultValue="pending">
          <TabsList className="mb-6" data-testid="tabs-registry-portal">
            <TabsTrigger value="pending" data-testid="tab-pending-queue">
              <Clock className="w-4 h-4 mr-2" /> Pending Queue
            </TabsTrigger>
            <TabsTrigger value="amendments" data-testid="tab-amendments">
              <Pencil className="w-4 h-4 mr-2" /> Amendment Requests
            </TabsTrigger>
            <TabsTrigger value="ledger" data-testid="tab-active-ledger">
              <FileText className="w-4 h-4 mr-2" /> Active Liens Ledger
            </TabsTrigger>
            <TabsTrigger value="reports" data-testid="tab-regulatory-reports">
              <BarChart3 className="w-4 h-4 mr-2" /> Regulatory Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-500" /> Pending Lien Registrations
                </CardTitle>
                <p className="text-sm text-muted-foreground">Review and approve or reject lien registration submissions from licensed financial institutions.</p>
              </CardHeader>
              <CardContent>
                <PendingQueue orgId={org?.id || ""} countryCode={countryCode} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="amendments">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Pencil className="w-5 h-5 text-blue-500" /> Amendment Requests
                </CardTitle>
                <p className="text-sm text-muted-foreground">Review amendment requests submitted by lenders for approved registrations. Approving a request applies the changes to the active record.</p>
              </CardHeader>
              <CardContent>
                <AmendmentQueue />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ledger">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gavel className="w-5 h-5 text-primary" /> Active Liens Ledger
                </CardTitle>
                <p className="text-sm text-muted-foreground">All approved and certified liens in your country's registry. Discharge liens when loans are repaid or flag for enforcement.</p>
              </CardHeader>
              <CardContent>
                <ActiveLiensLedger countryCode={countryCode} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-primary" /> Regulatory Summary Reports
                </CardTitle>
                <p className="text-sm text-muted-foreground">Aggregate collateral exposure across your financial system — by institution, asset type, and economic sector.</p>
              </CardHeader>
              <CardContent>
                <RegulatoryReports countryCode={countryCode} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
