import { db } from "./db";
import { sql } from "drizzle-orm";
import { storage } from "./storage";
import { retentionPolicies } from "@shared/schema";

const VALID_TABLES: Record<string, string> = {
  borrower: "borrowers",
  credit_account: "credit_accounts",
  audit_log: "audit_logs",
  dispute: "disputes",
  consent_record: "consent_records",
  court_judgment: "court_judgments",
  payment_history: "payment_history",
};

const AFRICAN_COUNTRIES = [
  "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi",
  "Cabo Verde", "Cameroon", "Central African Republic", "Chad", "Comoros",
  "Congo", "DR Congo", "Côte d'Ivoire", "Djibouti", "Egypt",
  "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia",
  "Ghana", "Guinea", "Guinea-Bissau", "Kenya", "Lesotho", "Liberia",
  "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius",
  "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Rwanda",
  "São Tomé and Príncipe", "Senegal", "Seychelles", "Sierra Leone",
  "Somalia", "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo",
  "Tunisia", "Uganda", "Zambia", "Zimbabwe", "All",
];
const VALID_COUNTRIES = new Set(AFRICAN_COUNTRIES);

type Resolver = "country" | "borrower_id" | "credit_account_id" | "global";

const ENTITY_RESOLVER: Record<string, Resolver> = {
  borrower: "country",
  credit_account: "borrower_id",
  audit_log: "global",
  dispute: "borrower_id",
  consent_record: "borrower_id",
  court_judgment: "borrower_id",
  payment_history: "credit_account_id",
};

export interface RetentionResult {
  policyId: string;
  country: string;
  entityType: string;
  archiveEligible: number;
  expungedCount: number;
  errors: string[];
}

function buildWhereClause(resolver: Resolver, country: string, tableName: string): ReturnType<typeof sql> {
  if (resolver === "country") {
    return sql`${sql.identifier(tableName)}.country = ${country}`;
  } else if (resolver === "borrower_id") {
    return sql`${sql.identifier(tableName)}.borrower_id IN (SELECT id FROM borrowers WHERE country = ${country})`;
  } else if (resolver === "credit_account_id") {
    return sql`${sql.identifier(tableName)}.credit_account_id IN (SELECT ca.id FROM credit_accounts ca JOIN borrowers b ON ca.borrower_id = b.id WHERE b.country = ${country})`;
  }
  return sql`TRUE`;
}

async function countEligible(tableName: string, resolver: Resolver, country: string, fromYears: number, toYears: number): Promise<number> {
  const whereClause = buildWhereClause(resolver, country, tableName);
  const result = await db.execute(sql`
    SELECT COUNT(*) as cnt FROM ${sql.identifier(tableName)}
    WHERE ${whereClause}
      AND created_at < NOW() - make_interval(years => ${fromYears})
      AND created_at >= NOW() - make_interval(years => ${toYears})
  `);
  return parseInt((result as any).rows?.[0]?.cnt || "0", 10);
}

async function getExpiredEntityIds(tableName: string, resolver: Resolver, country: string, years: number): Promise<string[]> {
  const whereClause = buildWhereClause(resolver, country, tableName);
  const result = await db.execute(sql`
    SELECT ${sql.identifier(tableName)}.id FROM ${sql.identifier(tableName)}
    WHERE ${whereClause}
      AND created_at < NOW() - make_interval(years => ${years})
  `);
  return ((result as any).rows || []).map((r: any) => r.id);
}

async function archiveExpired(tableName: string, resolver: Resolver, country: string, years: number, entityType: string, policyId: string): Promise<number> {
  const whereClause = buildWhereClause(resolver, country, tableName);
  const result = await db.execute(sql`
    SELECT * FROM ${sql.identifier(tableName)}
    WHERE ${whereClause}
      AND created_at < NOW() - make_interval(years => ${years})
  `);
  const rows = (result as any).rows || [];
  let archived = 0;
  for (const row of rows) {
    try {
      await db.execute(sql`
        INSERT INTO archived_records (entity_type, entity_id, country, policy_id, original_data)
        VALUES (${entityType}, ${row.id}, ${country}, ${policyId}, ${JSON.stringify(row)}::jsonb)
        ON CONFLICT (entity_type, entity_id) DO UPDATE SET original_data = ${JSON.stringify(row)}::jsonb, archived_at = now()
      `);
      await db.execute(sql`DELETE FROM ${sql.identifier(tableName)} WHERE id = ${row.id}`);
      archived++;
    } catch (e: any) {
      console.warn(`[Retention] Failed to archive ${entityType}/${row.id}:`, e.message);
    }
  }
  return archived;
}

async function expungeExpired(tableName: string, resolver: Resolver, country: string, years: number): Promise<number> {
  const whereClause = buildWhereClause(resolver, country, tableName);
  const result = await db.execute(sql`
    DELETE FROM ${sql.identifier(tableName)}
    WHERE ${whereClause}
      AND created_at < NOW() - make_interval(years => ${years})
  `);
  return (result as any).rowCount || 0;
}

export async function enforceRetentionPolicies(): Promise<RetentionResult[]> {
  /* GLOBAL: retention enforcement processes ALL countries' policies as a system job */
  const policies = await db.select().from(retentionPolicies).orderBy(retentionPolicies.country);
  const activePolicies = policies.filter((p) => p.isActive);
  const results: RetentionResult[] = [];

  for (const policy of activePolicies) {
    const result: RetentionResult = {
      policyId: policy.id,
      country: policy.country,
      entityType: policy.entityType,
      archiveEligible: 0,
      expungedCount: 0,
      errors: [],
    };

    try {
      const tableName = VALID_TABLES[policy.entityType];
      if (!tableName) {
        result.errors.push(`Unknown entity type: ${policy.entityType}`);
        results.push(result);
        continue;
      }

      if (!VALID_COUNTRIES.has(policy.country)) {
        result.errors.push(`Invalid country: ${policy.country}`);
        results.push(result);
        continue;
      }

      const resolver = ENTITY_RESOLVER[policy.entityType];
      const archiveYears = policy.archiveAfterYears ?? policy.retentionYears;
      const expungeYears = policy.retentionYears;
      const policyAction = (policy as any).action || "flag";

      result.archiveEligible = await countEligible(tableName, resolver, policy.country, archiveYears, expungeYears);

      if (policyAction === "delete") {
        result.expungedCount = await expungeExpired(tableName, resolver, policy.country, expungeYears);
      } else if (policyAction === "archive") {
        try {
          const archivedCount = await archiveExpired(tableName, resolver, policy.country, archiveYears, policy.entityType, policy.id);
          result.expungedCount = archivedCount;
        } catch (archErr: any) {
          result.errors.push(`Archive failed: ${archErr.message}`);
        }
      } else if (policyAction === "flag") {
        try {
          const flaggedIds = await getExpiredEntityIds(tableName, resolver, policy.country, archiveYears);
          for (const entityId of flaggedIds) {
            await db.execute(sql`
              INSERT INTO retention_flags (entity_type, entity_id, policy_id, action, country)
              VALUES (${policy.entityType}, ${entityId}, ${policy.id}, ${"flag"}, ${policy.country})
              ON CONFLICT (entity_type, entity_id, policy_id) DO UPDATE SET action = ${"flag"}, flagged_at = now()
            `);
          }
          result.expungedCount = flaggedIds.length;
        } catch (flagErr: any) {
          result.errors.push(`Flag persist failed: ${flagErr.message}`);
        }
      }
    } catch (err: any) {
      result.errors.push(err.message || String(err));
    }

    results.push(result);
  }

  return results;
}

let retentionTimer: NodeJS.Timeout | null = null;

export function startRetentionScheduler(intervalHours = 24) {
  console.log(`[Retention] Scheduler started — runs every ${intervalHours} hours`);

  retentionTimer = setInterval(async () => {
    console.log("[Retention] Running scheduled retention enforcement...");
    try {
      const results = await enforceRetentionPolicies();
      const summary = results.map(
        (r) => `${r.country}/${r.entityType}: eligible=${r.archiveEligible}, expunged=${r.expungedCount}${r.errors.length ? ` errors=${r.errors.join("; ")}` : ""}`
      );
      console.log("[Retention] Completed:", summary.join(" | "));

      await storage.createAuditLog({
        action: "retention_enforcement",
        entity: "system",
        details: JSON.stringify({
          results: results.map(({ policyId, country, entityType, archiveEligible, expungedCount, errors }) => ({
            policyId, country, entityType, archiveEligible, expungedCount, errors,
          })),
        }),
      });
    } catch (err) {
      console.error("[Retention] Enforcement error:", err);
    }
  }, intervalHours * 60 * 60 * 1000);
}

export function stopRetentionScheduler() {
  if (retentionTimer) {
    clearInterval(retentionTimer);
    retentionTimer = null;
  }
}
