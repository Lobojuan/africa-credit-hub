import nodemailer from "nodemailer";
import { isGhanaMode } from "./country-mode";

function redactEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!domain) return '[invalid]';
  return `${local.slice(0, 2)}***@${domain}`;
}

function esc(str: string | undefined | null): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

let transporter: nodemailer.Transporter | null = null;
let emailConfigured = false;
let emailProvider: "smtp" | "sendgrid" | "stub" = "stub";

const FROM_EMAIL = process.env.SMTP_FROM || process.env.PLATFORM_SUPPORT_EMAIL || "support@africacredithub.com";
const FROM_NAME = isGhanaMode() ? "Ghana Credit Registry" : "Pan-African Credit Registry";

async function sendViaSendGrid(to: string, subject: string, htmlBody: string): Promise<boolean> {
  const apiKey = process.env.SENDGRID_API_KEY;
  if (!apiKey) return false;
  try {
    const resp = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: to }] }],
        from: { email: FROM_EMAIL, name: FROM_NAME },
        subject,
        content: [{ type: "text/html", value: htmlBody }],
      }),
    });
    if (resp.ok || resp.status === 202) {
      console.log(`[Email][SendGrid] Sent to ${redactEmail(to)}`);
      return true;
    }
    console.error(`[Email][SendGrid] Failed ${resp.status}`);
    return false;
  } catch (err: any) {
    console.error(`[Email][SendGrid] Error:`, err.message);
    return false;
  }
}

let hasSendGrid = false;
let hasSmtp = false;

function initEmail() {
  if (process.env.SENDGRID_API_KEY) {
    hasSendGrid = true;
    emailProvider = "sendgrid";
    emailConfigured = true;
    console.log("[Email] SendGrid configured (API key found)");
  }

  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || "587");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (host && user && pass) {
    hasSmtp = true;
    if (!hasSendGrid) emailProvider = "smtp";
    transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
    });

    transporter.verify((err) => {
      if (err) {
        console.error("[Email] SMTP connection failed:", err.message);
        transporter = null;
        hasSmtp = false;
      } else {
        emailConfigured = true;
        console.log(`[Email] SMTP configured via ${host} (rate limit: ~500/day for Gmail)`);
      }
    });
  }

  if (!hasSendGrid && !hasSmtp) {
    console.log("[Email] No email provider configured — set SENDGRID_API_KEY or SMTP_HOST/SMTP_USER/SMTP_PASS (stub mode)");
  }
}

initEmail();

function createEmailHtml(title: string, bodyHtml: string): string {
  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f4f5f7;font-family:Arial,sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:40px 20px;">
    <div style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.08);">
      <div style="background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);padding:28px 32px;">
        <h1 style="color:#fff;margin:0;font-size:20px;font-weight:600;">Pan-African Credit Registry</h1>
        <p style="color:rgba(255,255,255,.7);margin:4px 0 0;font-size:13px;">${process.env.PLATFORM_COMPANY_NAME || "Africa Credit Hub"}</p>
      </div>
      <div style="padding:32px;">
        <h2 style="color:#1a1a2e;margin:0 0 16px;font-size:18px;">${title}</h2>
        ${bodyHtml}
      </div>
      <div style="background:#f8f9fa;padding:20px 32px;border-top:1px solid #eee;">
        <p style="color:#888;font-size:11px;margin:0;">This is an automated message from the Pan-African Credit Registry Platform. Do not reply to this email.</p>
      </div>
    </div>
  </div>
</body>
</html>`;
}

async function sendViaSmtp(to: string, subject: string, htmlBody: string): Promise<boolean> {
  if (!transporter) return false;
  try {
    await transporter.sendMail({
      from: `"${FROM_NAME}" <${FROM_EMAIL}>`,
      to,
      subject,
      html: htmlBody,
    });
    console.log(`[Email][SMTP] Sent to ${redactEmail(to)}`);
    return true;
  } catch (err: any) {
    console.error(`[Email][SMTP] Send failed:`, err.message);
    return false;
  }
}

async function sendViaSmtpWithAttachment(
  to: string,
  subject: string,
  htmlBody: string,
  attachment: { filename: string; content: Buffer; contentType: string },
): Promise<boolean> {
  if (!transporter) return false;
  try {
    await transporter.sendMail({
      from: `"${FROM_NAME}" <${FROM_EMAIL}>`,
      to,
      subject,
      html: htmlBody,
      attachments: [{ filename: attachment.filename, content: attachment.content, contentType: attachment.contentType }],
    });
    console.log(`[Email][SMTP] Sent with attachment to ${redactEmail(to)}`);
    return true;
  } catch (err: any) {
    console.error(`[Email][SMTP] Send with attachment failed:`, err.message);
    return false;
  }
}

async function sendViaSendGridWithAttachment(
  to: string,
  subject: string,
  htmlBody: string,
  attachment: { filename: string; content: Buffer; contentType: string },
): Promise<boolean> {
  const apiKey = process.env.SENDGRID_API_KEY;
  if (!apiKey) return false;
  try {
    const resp = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: to }] }],
        from: { email: FROM_EMAIL, name: FROM_NAME },
        subject,
        content: [{ type: "text/html", value: htmlBody }],
        attachments: [{
          content: attachment.content.toString("base64"),
          filename: attachment.filename,
          type: attachment.contentType,
          disposition: "attachment",
        }],
      }),
    });
    if (resp.ok || resp.status === 202) {
      console.log(`[Email][SendGrid] Sent with attachment to ${redactEmail(to)}`);
      return true;
    }
    console.error(`[Email][SendGrid] Failed ${resp.status} (with attachment)`);
    return false;
  } catch (err: any) {
    console.error(`[Email][SendGrid] Error (with attachment):`, err.message);
    return false;
  }
}

async function attemptSendWithAttachment(
  to: string,
  subject: string,
  htmlBody: string,
  attachment: { filename: string; content: Buffer; contentType: string },
): Promise<boolean> {
  if (emailProvider === "sendgrid") {
    const ok = await sendViaSendGridWithAttachment(to, subject, htmlBody, attachment);
    if (ok) return true;
    if (hasSmtp) {
      console.log(`[Email] SendGrid failed, falling back to SMTP (with attachment)...`);
      return sendViaSmtpWithAttachment(to, subject, htmlBody, attachment);
    }
    return false;
  }

  const ok = await sendViaSmtpWithAttachment(to, subject, htmlBody, attachment);
  if (ok) return true;
  if (hasSendGrid) {
    console.log(`[Email] SMTP failed, falling back to SendGrid (with attachment)...`);
    return sendViaSendGridWithAttachment(to, subject, htmlBody, attachment);
  }
  return false;
}

async function sendEmailWithAttachment(
  to: string,
  subject: string,
  htmlBody: string,
  attachment: { filename: string; content: Buffer; contentType: string },
): Promise<boolean> {
  if (!emailConfigured) {
    console.log(`[Email][Stub] Would send with attachment to ${redactEmail(to)}: ${attachment.filename}`);
    return false;
  }

  if (emailsSentThisMinute >= MAX_EMAILS_PER_MINUTE) {
    console.warn(`[Email] Rate limit reached (${MAX_EMAILS_PER_MINUTE}/min) — deferring attachment send to ${redactEmail(to)}`);
    return false;
  }

  for (let attempt = 0; attempt < RETRY_DELAYS.length; attempt++) {
    if (attempt > 0) {
      console.log(`[Email] Retry ${attempt}/${RETRY_DELAYS.length - 1} for ${redactEmail(to)} (attachment, waiting ${RETRY_DELAYS[attempt]}ms)...`);
      await sleep(RETRY_DELAYS[attempt]);
    }
    try {
      const ok = await attemptSendWithAttachment(to, subject, htmlBody, attachment);
      if (ok) {
        emailsSentThisMinute++;
        return true;
      }
    } catch (err: any) {
      console.error(`[Email] Attempt ${attempt + 1} error (with attachment):`, err.message);
    }
  }

  console.error(`[Email] All ${RETRY_DELAYS.length} attempts failed for ${redactEmail(to)} (with attachment) — subject: "${subject.substring(0, 60)}"`);
  return false;
}

const RETRY_DELAYS = [0, 2000, 8000];
const MAX_EMAILS_PER_MINUTE = 30;
let emailsSentThisMinute = 0;
let minuteResetTimer: ReturnType<typeof setInterval> | null = null;

if (!minuteResetTimer) {
  minuteResetTimer = setInterval(() => { emailsSentThisMinute = 0; }, 60000);
}

async function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function attemptSend(to: string, subject: string, htmlBody: string): Promise<boolean> {
  if (emailProvider === "sendgrid") {
    const ok = await sendViaSendGrid(to, subject, htmlBody);
    if (ok) return true;
    if (hasSmtp) {
      console.log(`[Email] SendGrid failed, falling back to SMTP...`);
      return sendViaSmtp(to, subject, htmlBody);
    }
    return false;
  }

  const ok = await sendViaSmtp(to, subject, htmlBody);
  if (ok) return true;
  if (hasSendGrid) {
    console.log(`[Email] SMTP failed, falling back to SendGrid...`);
    return sendViaSendGrid(to, subject, htmlBody);
  }
  return false;
}

async function sendEmail(to: string, subject: string, htmlBody: string): Promise<boolean> {
  if (!emailConfigured) {
    console.log(`[Email][Stub] Would send to ${redactEmail(to)}`);
    return false;
  }

  if (emailsSentThisMinute >= MAX_EMAILS_PER_MINUTE) {
    console.warn(`[Email] Rate limit reached (${MAX_EMAILS_PER_MINUTE}/min) — deferring send to ${redactEmail(to)}`);
    return false;
  }

  for (let attempt = 0; attempt < RETRY_DELAYS.length; attempt++) {
    if (attempt > 0) {
      console.log(`[Email] Retry ${attempt}/${RETRY_DELAYS.length - 1} for ${redactEmail(to)} (waiting ${RETRY_DELAYS[attempt]}ms)...`);
      await sleep(RETRY_DELAYS[attempt]);
    }
    try {
      const ok = await attemptSend(to, subject, htmlBody);
      if (ok) {
        emailsSentThisMinute++;
        return true;
      }
    } catch (err: any) {
      console.error(`[Email] Attempt ${attempt + 1} error:`, err.message);
    }
  }

  console.error(`[Email] All ${RETRY_DELAYS.length} attempts failed for ${redactEmail(to)} — subject: "${subject.substring(0, 60)}"`);
  return false;
}

export async function sendWelcomeEmail(orgName: string, adminEmail: string, tier: string): Promise<boolean> {
  const tierInfo: Record<string, { name: string; users: number; price: string }> = {
    standard: { name: "Standard", users: 10, price: "$299/mo" },
    professional: { name: "Professional", users: 50, price: "$799/mo" },
    enterprise: { name: "Enterprise", users: 100, price: "$1,999/mo" },
  };
  const plan = tierInfo[tier] || tierInfo.standard;

  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">Welcome to the Pan-African Credit Registry! Your organization <strong>${esc(orgName)}</strong> has been successfully registered.</p>
    <div style="background:#f0f7ff;border-radius:8px;padding:16px 20px;margin:16px 0;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Subscription Plan:</strong> ${plan.name} (${plan.price})</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Max Users:</strong> ${plan.users}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Coverage:</strong> All 54 African countries</p>
    </div>
    <p style="color:#333;font-size:14px;">You can now start submitting credit data, running inquiries, and generating reports across all supported jurisdictions.</p>
    <a href="https://africacredithub.com" style="display:inline-block;background:#1a1a2e;color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;margin-top:8px;">Access Your Dashboard</a>
  `;
  return sendEmail(adminEmail, `Welcome to Pan-African Credit Registry — ${orgName}`, createEmailHtml("Welcome Aboard!", body));
}

export async function sendBillingNotification(orgName: string, email: string, amount: number, currency: string, serviceType: string, status: string): Promise<boolean> {
  const statusColors: Record<string, string> = {
    paid: "#22c55e",
    pending: "#f59e0b",
    overdue: "#ef4444",
    cancelled: "#94a3b8",
  };
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">A billing event has occurred for <strong>${esc(orgName)}</strong>.</p>
    <div style="background:#f8f9fa;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid ${statusColors[status] || "#64748b"};">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Service:</strong> ${esc(serviceType)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Amount:</strong> ${currency} ${amount.toLocaleString()}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Status:</strong> <span style="color:${statusColors[status] || "#64748b"};font-weight:600;">${status.toUpperCase()}</span></p>
    </div>
  `;
  return sendEmail(email, `Billing Update — ${orgName} (${currency} ${amount.toLocaleString()})`, createEmailHtml("Billing Notification", body));
}

export async function sendDisputeNotification(orgName: string, email: string, disputeId: number, borrowerName: string, disputeType: string): Promise<boolean> {
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">A new credit dispute has been filed for <strong>${esc(orgName)}</strong>.</p>
    <div style="background:#fef3cd;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #f59e0b;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Dispute ID:</strong> #${disputeId}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Borrower:</strong> ${esc(borrowerName)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Type:</strong> ${esc(disputeType)}</p>
    </div>
    <p style="color:#333;font-size:14px;">Please review and respond to this dispute within 30 days as per regulatory requirements.</p>
    <a href="https://africacredithub.com" style="display:inline-block;background:#1a1a2e;color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;margin-top:8px;">Review Dispute</a>
  `;
  return sendEmail(email, `New Dispute Filed — ${orgName} (#${disputeId})`, createEmailHtml("Dispute Alert", body));
}

export async function sendSubscriptionChangeEmail(orgName: string, email: string, oldTier: string, newTier: string): Promise<boolean> {
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">The subscription for <strong>${esc(orgName)}</strong> has been updated.</p>
    <div style="background:#f0fdf4;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #22c55e;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Previous Plan:</strong> ${esc(oldTier)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>New Plan:</strong> ${esc(newTier)}</p>
    </div>
    <p style="color:#333;font-size:14px;">Your updated features and limits are now active.</p>
  `;
  return sendEmail(email, `Subscription Updated — ${orgName}`, createEmailHtml("Subscription Change", body));
}

export async function sendNewRegistrationAlert(orgName: string, orgType: string, country: string, contactEmail: string, adminName: string): Promise<boolean> {
  const NOTIFY_EMAIL = process.env.REGISTRATION_NOTIFY_EMAIL || process.env.PLATFORM_SUPPORT_EMAIL || "support@africacredithub.com";
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">A new organization has registered on the Pan-African Credit Registry.</p>
    <div style="background:#f0f7ff;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #3b82f6;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Organization:</strong> ${esc(orgName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Type:</strong> ${esc(orgType)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Country:</strong> ${esc(country)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Contact Email:</strong> ${esc(contactEmail)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Admin Name:</strong> ${esc(adminName)}</p>
    </div>
    <p style="color:#333;font-size:14px;">Registered at: ${new Date().toLocaleString("en-US", { timeZone: "Africa/Accra", dateStyle: "full", timeStyle: "short" })}</p>
    <a href="${process.env.CANONICAL_URL || 'https://africacredithub.com'}/command-center" style="display:inline-block;background:#1a1a2e;color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;margin-top:8px;">Open Command Center</a>
  `;
  return sendEmail(NOTIFY_EMAIL, `New Registration: ${orgName} (${country})`, createEmailHtml("New Trial Registration", body));
}

export async function sendConsumerOtpEmail(email: string, otp: string): Promise<boolean> {
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">Your verification code for Africa Credit Hub is:</p>
    <div style="background:#f0f7ff;border-radius:12px;padding:24px;margin:20px 0;text-align:center;">
      <span style="font-size:36px;font-weight:700;letter-spacing:8px;color:#1a1a2e;font-family:monospace;">${otp}</span>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">This code expires in <strong>10 minutes</strong>. Do not share it with anyone.</p>
    <p style="color:#888;font-size:12px;margin-top:20px;">If you did not request this code, please ignore this email.</p>
  `;
  return sendEmail(email, "Your Verification Code — Africa Credit Hub", createEmailHtml("Verify Your Account", body));
}

export async function sendConsumerVerificationLink(email: string, token: string, baseUrl: string): Promise<boolean> {
  const verifyUrl = `${baseUrl}/api/consumer/verify-email?token=${encodeURIComponent(token)}`;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">Click the button below to verify your Africa Credit Hub account:</p>
    <div style="text-align:center;margin:28px 0;">
      <a href="${verifyUrl}" style="display:inline-block;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:14px 36px;border-radius:8px;text-decoration:none;font-size:15px;font-weight:600;">Verify My Account</a>
    </div>
    <p style="color:#555;font-size:13px;line-height:1.5;">Or copy and paste this link into your browser:</p>
    <p style="color:#3b82f6;font-size:12px;word-break:break-all;">${verifyUrl}</p>
    <p style="color:#888;font-size:12px;margin-top:20px;">This link expires in <strong>24 hours</strong>. If you did not create this account, please ignore this email.</p>
  `;
  return sendEmail(email, "Verify Your Account — Africa Credit Hub", createEmailHtml("Email Verification", body));
}

export async function sendContactSalesEmail(data: { name: string; email: string; phone?: string; organization: string; title?: string; country?: string; tier?: string; message?: string }): Promise<boolean> {
  const adminEmail = process.env.ADMIN_EMAIL || process.env.PLATFORM_SUPPORT_EMAIL || "support@africacredithub.com";
  const tierLabel = data.tier === "commercial" ? "Commercial" : data.tier === "sovereign" ? "Sovereign" : data.tier || "Not specified";
  const body = `
    <h2 style="color:#0d9488;">New Enterprise Inquiry</h2>
    <table style="width:100%;border-collapse:collapse;margin:16px 0;">
      <tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;width:140px;">Name</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${esc(data.name)}</td></tr>
      <tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;">Email</td><td style="padding:8px 12px;border-bottom:1px solid #eee;"><a href="mailto:${esc(data.email)}">${esc(data.email)}</a></td></tr>
      ${data.phone ? `<tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;">Phone</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${esc(data.phone)}</td></tr>` : ""}
      <tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;">Organization</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${esc(data.organization)}</td></tr>
      ${data.title ? `<tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;">Job Title</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${esc(data.title)}</td></tr>` : ""}
      ${data.country ? `<tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;">Country</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${esc(data.country)}</td></tr>` : ""}
      <tr><td style="padding:8px 12px;border-bottom:1px solid #eee;font-weight:600;">Interested In</td><td style="padding:8px 12px;border-bottom:1px solid #eee;">${esc(tierLabel)}</td></tr>
    </table>
    ${data.message ? `<h3 style="margin-top:20px;">Message</h3><p style="background:#f8f9fa;padding:16px;border-radius:8px;white-space:pre-wrap;">${esc(data.message)}</p>` : ""}
    <p style="color:#888;font-size:12px;margin-top:24px;">This inquiry was submitted via the Africa Credit Hub Contact Sales page.</p>
  `;
  return sendEmail(adminEmail, `[Africa Credit Hub Sales Inquiry] ${data.organization} — ${tierLabel}`, createEmailHtml("New Sales Inquiry", body));
}

export async function sendConsentRequestEmail(
  borrowerEmail: string,
  borrowerName: string,
  lenderName: string,
  purpose: string,
  consentUrl: string,
  expiresHours: number = 24
): Promise<boolean> {
  const purposeLabels: Record<string, string> = {
    new_credit: "Credit Application / Loan Origination",
    review: "Account / Portfolio Review",
    collection: "Debt Collection",
    regulatory: "Regulatory / Supervisory Purpose",
    portfolio_monitoring: "Portfolio Monitoring",
    fraud_investigation: "Fraud Investigation",
    employment: "Employment Screening",
  };
  const purposeLabel = purposeLabels[purpose] || purpose;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">Dear <strong>${esc(borrowerName)}</strong>,</p>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      <strong>${esc(lenderName)}</strong> has requested access to your credit report through the Ghana Credit Registry.
      Your explicit consent is required before any report can be generated.
    </p>
    <div style="background:#f0f7ff;border-radius:12px;padding:20px;margin:20px 0;border-left:4px solid #2563eb;">
      <p style="margin:0 0 8px;color:#1e3a5f;font-size:13px;font-weight:600;">Request Details</p>
      <p style="margin:4px 0;color:#333;font-size:13px;"><strong>Requested by:</strong> ${esc(lenderName)}</p>
      <p style="margin:4px 0;color:#333;font-size:13px;"><strong>Purpose:</strong> ${esc(purposeLabel)}</p>
      <p style="margin:4px 0;color:#333;font-size:13px;"><strong>Expires:</strong> ${expiresHours} hours from now</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Please review this request and click <strong>Approve</strong> or <strong>Deny</strong> below.
      You have the right to deny this request — denying will prevent access to your credit report.
    </p>
    <div style="text-align:center;margin:28px 0;display:flex;gap:12px;justify-content:center;">
      <a href="${consentUrl}&decision=approved" style="display:inline-block;background:#16a34a;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-size:15px;font-weight:600;margin-right:8px;">✓ Approve</a>
      <a href="${consentUrl}&decision=denied" style="display:inline-block;background:#dc2626;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-size:15px;font-weight:600;">✗ Deny</a>
    </div>
    <p style="color:#555;font-size:13px;line-height:1.5;">Or open this link to review and respond:</p>
    <p style="color:#3b82f6;font-size:12px;word-break:break-all;">${consentUrl}</p>
    <p style="color:#888;font-size:12px;margin-top:20px;line-height:1.6;">
      This request will expire in <strong>${expiresHours} hours</strong>. If you did not expect this request, you may safely ignore or deny it.
      Your credit data is protected under the Ghana Data Protection Act.
    </p>
  `;
  return sendEmail(borrowerEmail, `Credit Report Access Request — ${lenderName}`, createEmailHtml("Credit Report Consent Request", body));
}

export async function sendCollectionSlaBreachEmail(
  agentEmail: string,
  assignmentId: string,
  borrowerId: string,
  priority: string,
  thresholdDays: number,
  caseUrl: string
): Promise<boolean> {
  const priorityColors: Record<string, string> = {
    urgent: "#ef4444",
    high: "#f97316",
    medium: "#f59e0b",
    low: "#64748b",
  };
  const color = priorityColors[priority] || "#64748b";
  const priorityLabel = priority.charAt(0).toUpperCase() + priority.slice(1);

  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">A collection case assigned to you has breached its SLA threshold and requires immediate attention.</p>
    <div style="background:#fff5f5;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid ${color};">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Priority:</strong> <span style="color:${color};font-weight:600;">${esc(priorityLabel)}</span></p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Borrower ID:</strong> ${esc(borrowerId)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Days without contact:</strong> ${thresholdDays}+ days</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Assignment ID:</strong> #${assignmentId}</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">Please contact this borrower as soon as possible to bring the case back within SLA.</p>
    <div style="text-align:center;margin:24px 0;">
      <a href="${esc(caseUrl)}" style="display:inline-block;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600;">View Case</a>
    </div>
    <p style="color:#888;font-size:12px;margin-top:16px;">You will not receive another email alert for this case for the next 24 hours.</p>
  `;

  return sendEmail(
    agentEmail,
    `SLA Breach — ${priorityLabel} Priority Collection Case #${assignmentId}`,
    createEmailHtml("Collection SLA Breach Alert", body)
  );
}

interface EmailThresholdContext {
  isCustom: boolean;
  consecutiveFailures: number;
  criticalFail7d?: number | null;
  criticalStreak30d?: number | null;
}

function formatThresholdForEmail(ctx: EmailThresholdContext): string {
  if (ctx.isCustom) {
    const parts: string[] = [];
    if (ctx.criticalFail7d != null) parts.push(`${ctx.criticalFail7d} failures in 7 days`);
    if (ctx.criticalStreak30d != null) parts.push(`streak: ${ctx.criticalStreak30d} in 30 days`);
    const detail = parts.length ? ` — ${parts.join(", ")}` : "";
    return `Custom override${detail} (alert trigger: ${ctx.consecutiveFailures} consecutive failures)`;
  }
  return `Global default — ${ctx.consecutiveFailures} consecutive failures`;
}

export async function sendRegistryDownEmail(
  to: string,
  provider: string,
  error: string,
  isRecovery = false,
  thresholdCtx?: EmailThresholdContext,
): Promise<boolean> {
  const providerLabel = provider
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
  const subject = isRecovery
    ? `[Resolved] Registry Back Online: ${providerLabel}`
    : `[Alert] Registry Down: ${providerLabel}`;

  const thresholdRow = !isRecovery && thresholdCtx
    ? `<p style="margin:4px 0 0;font-size:13px;color:#555;"><strong>Threshold:</strong> ${esc(formatThresholdForEmail(thresholdCtx))}</p>`
    : "";

  const body = isRecovery
    ? `
      <p style="color:#333;font-size:14px;line-height:1.6;">
        The <strong>${esc(providerLabel)}</strong> registry is now responding normally and has been marked as operational.
      </p>
      <div style="background:#f0fdf4;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #22c55e;">
        <p style="margin:0;font-size:13px;color:#555;"><strong>Registry:</strong> ${esc(providerLabel)}</p>
        <p style="margin:4px 0 0;font-size:13px;color:#555;"><strong>Status:</strong> <span style="color:#16a34a;font-weight:600;">Operational</span></p>
        <p style="margin:4px 0 0;font-size:13px;color:#555;"><strong>Time:</strong> ${new Date().toUTCString()}</p>
      </div>
      <p style="color:#333;font-size:14px;line-height:1.6;">No further action is required. Asset traces for this registry will resume normally.</p>
    `
    : `
      <p style="color:#333;font-size:14px;line-height:1.6;">
        The <strong>${esc(providerLabel)}</strong> live registry has failed consecutive health checks and may be unreachable.
      </p>
      <div style="background:#fff5f5;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #ef4444;">
        <p style="margin:0;font-size:13px;color:#555;"><strong>Registry:</strong> ${esc(providerLabel)}</p>
        <p style="margin:4px 0 0;font-size:13px;color:#555;"><strong>Error:</strong> <span style="color:#dc2626;">${esc(error)}</span></p>
        <p style="margin:4px 0 0;font-size:13px;color:#555;"><strong>Detected at:</strong> ${new Date().toUTCString()}</p>
        ${thresholdRow}
      </div>
      <p style="color:#333;font-size:14px;line-height:1.6;">Asset traces using this registry will return errors until the issue is resolved. Please check the registry endpoint configuration and contact the registry authority if the problem persists.</p>
      <p style="color:#333;font-size:14px;line-height:1.6;">View the System Status page to monitor live health and run manual tests.</p>
    `;

  return sendEmail(to, subject, createEmailHtml(
    isRecovery ? "Registry Recovery" : "Registry Down Alert",
    body,
  ));
}

export async function sendRegistryAuthorityWelcomeEmail(
  orgName: string,
  countryName: string,
  contactEmail: string,
  username: string,
  temporaryPassword: string,
): Promise<boolean> {
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Welcome! The <strong>${esc(orgName)}</strong> has been provisioned as the official Registry Authority for <strong>${esc(countryName)}</strong> on the Pan-African Collateral Registry platform.
    </p>
    <div style="background:#f0fdf4;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #16a34a;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Organization:</strong> ${esc(orgName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Country:</strong> ${esc(countryName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Username:</strong> <code style="background:#e5e7eb;padding:2px 6px;border-radius:4px;">${esc(username)}</code></p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Temporary Password:</strong> <code style="background:#e5e7eb;padding:2px 6px;border-radius:4px;">${esc(temporaryPassword)}</code></p>
    </div>
    <p style="color:#dc2626;font-size:13px;font-weight:600;">You will be required to change your password on first login. Keep these credentials secure and do not share them.</p>
    <p style="color:#333;font-size:14px;line-height:1.6;">As a Registry Authority administrator, you can approve and reject lien registrations, manage collateral filings, and oversee registry operations for your country.</p>
    <a href="https://africacredithub.com" style="display:inline-block;background:#1a1a2e;color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;margin-top:8px;">Access Your Dashboard</a>
  `;
  return sendEmail(
    contactEmail,
    `Registry Authority Access — ${orgName} (${countryName})`,
    createEmailHtml("Registry Authority Provisioned", body),
  );
}

export async function sendLienApprovalEmail(
  lenderEmail: string,
  lenderOrgName: string,
  certificateNumber: string,
  priorityRank: number,
  collateralId: string,
  assetDescription: string,
  baseUrl: string,
): Promise<boolean> {
  const certUrl = `${baseUrl}/api/collateral/${collateralId}/certificate`;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Good news! Your lien registration has been <strong style="color:#16a34a;">approved</strong> by the Registry Authority.
    </p>
    <div style="background:#f0fdf4;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #16a34a;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Organisation:</strong> ${esc(lenderOrgName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Certificate Number:</strong> <code style="background:#e5e7eb;padding:2px 6px;border-radius:4px;">${esc(certificateNumber)}</code></p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Priority Rank:</strong> #${priorityRank}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Asset:</strong> ${esc(assetDescription)}</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Your lien has been registered and is now publicly searchable in the Pan-African Collateral Registry. You can download your certificate of registration using the link below.
    </p>
    <div style="text-align:center;margin:24px 0;">
      <a href="${esc(certUrl)}" style="display:inline-block;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600;">Download Certificate (PDF)</a>
    </div>
    <p style="color:#888;font-size:12px;margin-top:16px;">Keep this certificate as proof of your registered security interest. If you have any questions, please contact support.</p>
  `;
  return sendEmail(
    lenderEmail,
    `Lien Registration Approved — Certificate ${certificateNumber}`,
    createEmailHtml("Lien Registration Approved", body),
  );
}

export async function sendLienRejectionEmail(
  lenderEmail: string,
  lenderOrgName: string,
  rejectionReason: string,
  assetDescription: string,
  baseUrl: string,
): Promise<boolean> {
  const portalUrl = `${baseUrl}/collateral`;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">
      We regret to inform you that your lien registration has been <strong style="color:#dc2626;">rejected</strong> by the Registry Authority.
    </p>
    <div style="background:#fff5f5;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #dc2626;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Organisation:</strong> ${esc(lenderOrgName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Asset:</strong> ${esc(assetDescription)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Reason for Rejection:</strong> ${esc(rejectionReason)}</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Please review the rejection reason above, correct any issues with your submission, and re-submit your registration through the portal.
    </p>
    <div style="text-align:center;margin:24px 0;">
      <a href="${esc(portalUrl)}" style="display:inline-block;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600;">Go to Collateral Portal</a>
    </div>
    <p style="color:#888;font-size:12px;margin-top:16px;">If you believe this rejection was made in error, please contact the Registry Authority or support for assistance.</p>
  `;
  return sendEmail(
    lenderEmail,
    `Lien Registration Rejected — Action Required`,
    createEmailHtml("Lien Registration Rejected", body),
  );
}

export async function sendLienEnforcementEmail(
  lenderEmail: string,
  lenderOrgName: string,
  assetDescription: string,
  baseUrl: string,
): Promise<boolean> {
  const portalUrl = `${baseUrl}/collateral-registry`;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">
      We are writing to inform you that one of your registered collateral items has been placed <strong style="color:#b45309;">in enforcement</strong> by the Registry Authority.
    </p>
    <div style="background:#fffbeb;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #d97706;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Organisation:</strong> ${esc(lenderOrgName)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Asset:</strong> ${esc(assetDescription)}</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      <strong>What this means:</strong> The Registry Authority has initiated enforcement proceedings against this collateral. This typically occurs when a borrower has defaulted on their obligations and you as the secured party are entitled to exercise your rights under the registered security interest.
    </p>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      <strong>Recommended next steps:</strong>
    </p>
    <ul style="color:#333;font-size:14px;line-height:1.8;padding-left:20px;">
      <li>Log in to the registry portal and review the full details of this collateral registration.</li>
      <li>Consult your legal counsel regarding enforcement rights and procedures in the relevant jurisdiction.</li>
      <li>Contact the Registry Authority if you require further clarification on the enforcement action.</li>
    </ul>
    <div style="text-align:center;margin:24px 0;">
      <a href="${esc(portalUrl)}" style="display:inline-block;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600;">View Collateral Portal</a>
    </div>
    <p style="color:#888;font-size:12px;margin-top:16px;">If you believe this enforcement action was raised in error, please contact the Registry Authority or our support team immediately.</p>
  `;
  return sendEmail(
    lenderEmail,
    `Collateral In Enforcement — Action May Be Required`,
    createEmailHtml("Collateral Placed In Enforcement", body),
  );
}

export async function sendLienReleaseEmail(
  lenderEmail: string,
  lenderOrgName: string,
  assetDescription: string,
  baseUrl: string,
): Promise<boolean> {
  const portalUrl = `${baseUrl}/collateral-registry`;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">
      We are writing to confirm that your collateral registration has been <strong style="color:#0369a1;">released / discharged</strong> by the Registry Authority.
    </p>
    <div style="background:#f0f9ff;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #0284c7;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Organisation:</strong> ${esc(lenderOrgName)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Asset:</strong> ${esc(assetDescription)}</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      <strong>What this means:</strong> The security interest registered against this collateral has been formally discharged and is no longer enforceable. The asset is no longer encumbered by your lien in the Pan-African Collateral Registry.
    </p>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Please update your internal records accordingly. If this release was not expected or was made in error, contact the Registry Authority as soon as possible.
    </p>
    <div style="text-align:center;margin:24px 0;">
      <a href="${esc(portalUrl)}" style="display:inline-block;background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;font-weight:600;">View Collateral Portal</a>
    </div>
    <p style="color:#888;font-size:12px;margin-top:16px;">If you have any questions about this discharge, please contact the Registry Authority or our support team.</p>
  `;
  return sendEmail(
    lenderEmail,
    `Collateral Registration Released / Discharged`,
    createEmailHtml("Collateral Registration Released", body),
  );
}

export async function sendCollateralVerificationLinkEmail(
  to: string,
  lenderName: string,
  verificationUrl: string,
  collateralDescription: string,
  borrowerName: string,
  personalMessage?: string,
): Promise<boolean> {
  const personalMessageSection = personalMessage
    ? `<div style="background:#fffbeb;border-radius:8px;padding:14px 18px;margin:16px 0;border-left:4px solid #f59e0b;">
        <p style="margin:0 0 4px;font-size:12px;color:#92400e;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;">Personal message from ${esc(lenderName)}</p>
        <p style="margin:0;font-size:14px;color:#333;line-height:1.6;">${esc(personalMessage)}</p>
      </div>`
    : "";
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">
      <strong>${esc(lenderName)}</strong> has shared a collateral verification link with you via the Pan-African Credit Registry.
    </p>
    <div style="background:#f0f9ff;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #0ea5e9;">
      <p style="margin:0 0 6px;font-size:13px;color:#555;"><strong>Borrower:</strong> ${esc(borrowerName)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Collateral:</strong> ${esc(collateralDescription)}</p>
    </div>
    ${personalMessageSection}
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Click the button below to verify the authenticity and status of this registered security interest on the public registry.
    </p>
    <a href="${verificationUrl}" style="display:inline-block;background:#1a1a2e;color:#fff;padding:12px 28px;border-radius:6px;text-decoration:none;font-size:14px;margin-top:8px;">Verify Registration</a>
    <p style="color:#888;font-size:12px;margin-top:16px;">Or copy this link: <a href="${verificationUrl}" style="color:#0ea5e9;">${verificationUrl}</a></p>
  `;
  return sendEmail(
    to,
    `Collateral Verification Link — ${lenderName}`,
    createEmailHtml("Collateral Verification", body),
  );
}

export function isEmailConfigured(): boolean {
  return emailConfigured;
}

export async function sendCertificateEmail(
  to: string,
  opts: {
    recipientLabel: string;
    certNumber: string;
    regNumber: string;
    borrowerName: string;
    lenderOrgName: string;
    countryCode: string;
    approvalDate: string;
    pdfBuffer: Buffer;
  },
): Promise<boolean> {
  const { recipientLabel, certNumber, regNumber, borrowerName, lenderOrgName, countryCode, approvalDate, pdfBuffer } = opts;
  const body = `
    <p style="color:#333;font-size:14px;line-height:1.6;">Dear ${esc(recipientLabel)},</p>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      A collateral financing statement has been <strong style="color:#16a34a;">approved</strong> on the Pan-African Collateral Registry.
      The official certificate is attached to this email as a PDF.
    </p>
    <div style="background:#f0fdf4;border-radius:8px;padding:16px 20px;margin:16px 0;border-left:4px solid #16a34a;">
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Certificate Number:</strong> ${esc(certNumber)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Registration Number:</strong> ${esc(regNumber)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Secured Party / Lender:</strong> ${esc(lenderOrgName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Borrower / Grantor:</strong> ${esc(borrowerName)}</p>
      <p style="margin:0 0 8px;font-size:13px;color:#555;"><strong>Country:</strong> ${esc(countryCode)}</p>
      <p style="margin:0;font-size:13px;color:#555;"><strong>Approval Date:</strong> ${esc(approvalDate)}</p>
    </div>
    <p style="color:#333;font-size:14px;line-height:1.6;">
      Please retain this certificate for your records. You may also download it at any time from the registry portal.
    </p>
  `;
  const subject = `Collateral Certificate Issued — ${regNumber} (${certNumber})`;
  const htmlBody = createEmailHtml("Financing Statement Certificate", body);
  const filename = `cert-${regNumber}.pdf`;
  return sendEmailWithAttachment(to, subject, htmlBody, { filename, content: pdfBuffer, contentType: "application/pdf" });
}
